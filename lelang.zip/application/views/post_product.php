<div class="main">
    <div class="content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Lelang Barang   
                </div>
                <div class="panel-body">
				<!--FORM -->
                <table width="100%">
					<thead>
					<tr>
						<td width="250">Id
						</td>
						<td>Nama Barang
						</td>
						<td>Harga
						</td>
					</tr>
					</thead>
					<tr>
						<td>
							<img src="<?php echo base_url(); ?>assets/images/feature-pic1.jpg" alt="" />
						</td>
						<td>aaaa
						</td>
						<td>aaaa
						</td>
					</tr>
					<tr>
						<td>
							<img src="<?php echo base_url(); ?>assets/images/feature-pic1.jpg" alt="" />
						</td>
						<td>aaaa
						</td>
						<td>aaaa
						</td>
					</tr>
                </table>
				<!-- END FORM -->
                </div>
			</div>
		
    </div>
 </div>