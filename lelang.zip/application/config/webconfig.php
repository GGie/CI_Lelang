<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['logo'] = "tesssssssssssssssss";
$config['description'] = "tesssssssssssssssss";
$config['keyword'] = "tesssssssssssssssss";
$config['max_prod'] = "tesssssssssssssssss";