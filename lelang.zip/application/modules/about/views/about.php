    <div class="center_content">
      <div class="center_title_bar">About</div>
      <div class="prod_box_big">
Lelang Product
      </div>
    </div>